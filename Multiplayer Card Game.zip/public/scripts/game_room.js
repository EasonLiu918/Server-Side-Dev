const GameRoom = (function() {
    // This stores the signed in user
    let user = null;
	//stage 3.1
	let socket = null;
	
	let myHand = null;
	let currentPlayers = {};
	let inGame = false;
//	let myIndex = 1;
	
	let remainingCount = 2;
	let winnerShown = false;
	
	const showLobby = function(){
		inGame = false;
		$("#lobby-area").show();
		$("#card-game-play-page").hide();
	}
	
	const showGamePlay = function(){
		inGame = true;
		$("#lobby-area").hide();
		$("#card-game-play-page").show();
	}
	
	const updateReplaceUI = function(){
		const selected = $("#in-game-player .me .hand .card.flipped").length;
		
		$("#selected-count").text(selected);
		$("#replacements-left").text(remainingCount);

		//提示文字
		if (selected == 0){
			$("#replace-hint").text("Select cards then click Replace.");
		}
		else{
			$("#replace-hint").text(`Selected ${selected} card(s).`);
		}
		
		//disable 規則
		//1. winner overlay 出現時不可換
		//2. remainingCount = 0 時不可換
		//3. selected = 0 時不可換
		
		const disableReplace = winnerShown || remainingCount == 0 || selected == 0 ;
			$("#replace-cards-button").prop("disabled", disableReplace);
	};
	
	const showReplaceToast = function(msg){
		$("#replace-toast").text(msg).stop(true, true).show();
		setTimeout(() => $("#replace-toast").fadeOut(200), 900);
	};
	
	const connectSocketAndJoin = function(){
		//避免重複建立Socket
		if (socket && socket.connected) return;
		
		socket = io();
		
		// Handle the error for the join request
		socket.on("join_error", (msg) => {
			
			// Show the error
			$("#signin-message").text(msg);
						
			// Show the page if unsuccessfully joined
			$("#game-room-content-page").hide();
			$("#game-room-signin-page").show();
			
			if (socket) {
				socket.disconnect();
				socket = null;
			}
		});
			
		// The player joins the game successfully
		socket.on("join_success", () => {
			console.log("join_success");
			$("#ready-button").show();
		});
			
			
		socket.on("update_players", (players) => {
			currentPlayers = players;
			if(!inGame){
				updatePlayers(players);
			}
			else{};
		});
			
		socket.on("deal_hand" , (payload) => {
			const hand = payload.hand;
			remainingCount = payload.remainingCount;

			winnerShown = false;
			showGamePlay();
						
			$("#game-message").removeClass("winner-overlay").text("").hide();
			$("#replace-cards-button").show();
			$("#confirm-hand-button").show();
						
			$("#restart-button").hide();
						
			//$("#replace-cards-button").prop("disabled", false);
			$("#confirm-hand-button").prop("disabled", false);
						
			renderInGamePlayers(currentPlayers, hand);
			updateReplaceUI();
		});
			
		socket.on("replace_error" , (msg) => {
			console.log("replace_error");
			alert(msg);
		});
		
		socket.on("replace_success", (result) => {
			console.log("replace_success", result);
			myHand = result.hand;
			remainingCount = result.remainingCount;	
						
			renderInGamePlayers(currentPlayers, myHand);
						
			showReplaceToast("Cards replace.");
						
			updateReplaceUI();
		});
		
		socket.on("game_aborted", (payload) =>
		{
			console.log("game_aborted", payload);
						
			showLobby();
						
			$("#lobby-message").text(payload?.reason || "Game aborted. Back to lobby.");

			$("#ready-button").show();
		});
		
		socket.on("confirm_error" , (msg) => {
			alert(msg);
			$("#confirm-hand-button").prop("disabled", false);
			winnerShown = false;
			updateReplaceUI();
		});
		
		socket.on("confirm_result", (result) => {
					
			// 1) 翻開所有人的牌
			//    result.players: [{id, username, hand, desc}]
			$("#in-game-player").html("");
					
			for (const p of result.players) {
			
			const box = $(`
				<div class="col player">
					<div class="player-name"></div>
					<div class="hand"></div>
					<div class="status"></div>
				</div>
			`);				
						
			if (socket && p.id == socket.id) box.addClass("me");
			box.find(".player-name").text(p.username);
			Hand.draw(box.find(".hand"), p.hand, false);  // confirm 後大家都不可點
			box.find(".status").text(p.desc.replaceAll("_", " "));
							
			$("#in-game-player").append(box);
			}	
						
			// 2) 顯示 winner
			const winnersText = result.winners.map(w => w.username).join(", ");
			$("#game-message").addClass("winner-overlay");
			$("#game-message").text(`Winner: ${winnersText}`);
			$("#game-message").show();
						
			winnerShown = true;
			updateReplaceUI();
			//$("#replace-cards-button").prop("disabled", true);
			$("#confirm-hand-button").prop("disabled", true);						
			$("#restart-button").show();
		});
					
		socket.emit("join", user.username);
	};
	
	
    const init = function() {
		
		showLobby();
		
        // Populate the avatar selection
        Avatar.populate($("#register-avatar"));

        $("#start-signin-button").on("click", function() {
            // Show the signin page
            $("#game-room-start-page").hide();
            $("#game-room-signin-page").show();
            $("#signin-form").get(0).reset();
            $("#signin-message").text("");
        });

        $("#start-register-button").on("click", function() {
            // Show the register page
            $("#game-room-start-page").hide();
            $("#game-room-register-page").show();
            $("#register-form").get(0).reset();
            $("#register-message").text("");
        });

        $(".back-button").on("click", function() {
            // Show the start page
            $("#game-room-start-page").show();
            $("#game-room-signin-page").hide();
            $("#game-room-register-page").hide();
        });

        $("#register-button").on("click", function(e) {
            // Do not submit the form
            e.preventDefault();

            //
            // A. Preparing the user data
            //

            // Get the input fields
            const username = $("#register-username").val().trim();
            const avatar   = $("#register-avatar").val();
            const name     = $("#register-name").val().trim();
            const password = $("#register-password").val().trim();
            const confirmPassword = $("#register-confirm").val().trim();

            // Password and confirmation does not match
            if (password != confirmPassword) {
                $("#register-message").text("Passwords do not match.");
                return;
            }
            
            // Create the JSON data
            const json = JSON.stringify({ username, avatar, name, password });

            //
            // B. Sending the AJAX request to the server
            //

            // Send a register request
            fetch("/register", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: json
            })
                .then((res) => res.json())
                .then((json) => {
                    console.log("Endpoint '/register' -", json); // FOR MARKING - DON'T DELETE

                    //
                    // F. Processing any error returned by the server
                    //
                    if (json.error) {
                        $("#register-message").text(json.error);
                        return;
                    }

                    //
                    // J. Handling the success response from the server
                    //
                    $("#register-form").get(0).reset();
                    $("#register-message").text("Your account has been successfully registered.");
                })
                .catch((err) => {
                    $("#register-message").text(err);
                });
        });

        $("#signin-button").on("click", function(e) {
            // Do not submit the form
            e.preventDefault();

            // Get the input fields
            const username = $("#signin-username").val().trim();
            const password = $("#signin-password").val().trim();

            //
            // A. Preparing the user data
            //

            // Create the JSON data
            const json = JSON.stringify({ username, password });

            //
            // B. Sending the AJAX request to the server
            //

            // Send a signin request
            fetch("/signin", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: json
            })
                .then((res) => res.json())
                .then((json) => {
                    console.log("Endpoint '/signin' -", json); // FOR MARKING - DON'T DELETE

                    //
                    // F. Processing any error returned by the server
                    //
                    if (json.error) {
                        $("#signin-message").text(json.error);
                        return;
                    }

                    //
                    // H. Handling the success response from the server
                    //

                    // Set the user information
                    user = json.user;
                    $("#game-room-user-avatar").html(Avatar.getCode(user.avatar));
                    $("#game-room-user-name").text(user.name);

                    // Show the content page
                    $("#game-room-signin-page").hide();
                    $("#game-room-content-page").show();
				
					connectSocketAndJoin();
				})
				
				.catch((err) => {
                    $("#signin-message").text(err);
                });
        });


        $("#ready-button").on("click", function(e) {
            // Do not submit the form
            e.preventDefault();

            // Send the WebSocket message to the server
            socket.emit("ready");

            // Hide the ready button
            $("#ready-button").hide();
            $("#lobby-message").text("Please wait for other players...");
        });
		
		

        // Click event for the signout button
        $("#signout-button").on("click", function(e) {
            // Do not submit the form
            e.preventDefault();

            // Send a signout request
            fetch("/signout")
                .then((res) => res.json())
                .then((json) => {
                    console.log("Endpoint '/signout' -", json); // FOR MARKING - DON'T DELETE

                    if (json.error) {
                        console.log(json.error);
                        return;
                    }
					
					if (socket)
					{
						socket.disconnect();
						socket = null;
					}
                    // Clear the user information
                    user = null;

                    // Show the start page
                    $("#game-room-content-page").hide();
                    $("#game-room-start-page").show();
                })
                .catch((err) => {
                    console.log(err);
                });
        });
		
        $("#replace-cards-button").on("click", function() {
			console.log("[UI] replace button clicked");
			console.log("[UI] socket?", socket && socket.connected);
            // Construct the cards to be replaced
			updateReplaceUI();
			const selected = $("#in-game-player .me .hand .card.flipped").length;
			if (winnerShown || remainingCount == 0 || selected == 0) return;
			
			
            const cards = [];
//			console.log("[UI] myIndex =", myIndex);
			console.log("[UI] flipped count =", $("#in-game-player .me .hand .card.flipped").length);
			
			$("#in-game-player .me .hand .card.flipped").each(function(idx, el) {
				cards.push($(el).attr("data-card"));
			});

			//
			// Replace the cards for the player by
			// sending a WebSocket message to the server
			//
			console.log("[UI] cards to replace =", cards);
			socket.emit("replacecards", cards);

        });

		$(document).on("click", "#in-game-player .me .hand .card", function() {
			setTimeout(updateReplaceUI, 0);
		});


        $("#confirm-hand-button").on("click", function() {
			
			$("#confirm-hand-button").prop("disabled", true);
			$("#game-message").removeClass("winner-overlay");
			$("#game-message").text("You confirmed. Waiting for others...");
			$("#game-message").show();
			
			winnerShown = true;
			updateReplaceUI();
			
			socket.emit("confirm");		
        });
		
		$("#restart-button").on("click", function(e) {
			e.preventDefault();
			
			//隱藏按鈕，避免重複點擊
			$("#restart-button").hide();
			
			// 清掉 Winner overlay（新一局重新發牌）
			$("#game-message").removeClass("winner-overlay").text("").hide();
			
			//告訴server 重開
			socket.emit("restart");
		});
		
    }

    const updatePlayers = function(players) {
		$(".player").hide();
		
        // Put the players in each box
        let index = 1;
        for (const id in players) {
            const player = players[id];

            // Show the correct status
//			if(id == socket.id) myIndex = index;
			
            let name = "You are";
            if (id != socket.id)
                name = `${player["username"]} is`;
            let status = "";
            if (player["ready"])
				status = `${name} ready!`;
            else
                status = `${name} not yet ready!`;
			
			// Update name + status
			$("#player" + index).find(".player-name").text(player["username"]);
            $("#player" + index).find(".status").text(status);
            $("#player" + index).show();
			index++;
        }
		
    };
	
	const renderInGamePlayers = function(players, myHandFromServer){
		myHand = myHandFromServer;
		
		$("#in-game-player").html("");
		
		let index = 1;
			for (const id in players){
				const p = players[id];
				
				const box = $(`
				<div class="col player">
					<div class="player-name"></div>
					<div class="hand"></div>
				</div>
				`);
			
				if (id == socket.id) box.addClass("me");
			
				box.find(".player-name").text(p.username);
				
				const handEl = box.find(".hand");
				
				if (id == socket.id){
					Hand.draw(handEl, myHand, true);
				}
				else {
					Hand.draw(handEl, new Array(5), false);
				}
				
				$("#in-game-player").append(box);
				index++;
			}	
	};
	

    const validate = function() {
        // Send a validate request
        fetch("/validate")
            .then((res) => res.json())
            .then((json) => {
                console.log("Endpoint '/validate' -", json); // FOR MARKING - DON'T DELETE

                //
                // C. Processing any error returned by the server
                //

                if (json.error) {
                    console.log(json.error);
                    return;
                }

                //
                // E. Handling the success response from the server
                //

                // Set the user information
                user = json.user;
                $("#game-room-user-avatar").html(Avatar.getCode(user.avatar));
                $("#game-room-user-name").text(user.name);

                // Show the content page
                $("#game-room-start-page").hide();
                $("#game-room-content-page").show();
				connectSocketAndJoin();

            })

            .catch((err) => {
                console.log(err);
            });
    }

    return { init, validate };
})();
