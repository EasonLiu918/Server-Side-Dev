// Show the welcome page
const welcome = (req, res) => res.render("welcome");

module.exports = { welcome };
