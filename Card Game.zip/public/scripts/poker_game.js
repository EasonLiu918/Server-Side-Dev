const PokerGame = (function() {
    // This stores the player's hand
    let player = [];

    const init = function() {
        $("#start-game-button").on("click", function() {
            // Ask the server to start the game
            fetch("/start")
                .then((res) => res.json())
                .then((json) => {
                    if (json.error) {
                        alert(json.error);
                        return;
                    }

                    console.log(JSON.stringify(json)); // FOR MARKING - DON'T DELETE

                    // Show the game play area
                    $("#card-game-start-page").hide();
                    $("#card-game-play-page").show();

                    // Show an empty hand for the computer
                    Hand.draw($("#computer-hand"), new Array(5), false);

                    //
                    // Get and show the player's hand
					player = json.hand;
					Hand.draw($("#player-hand"), player, true);                    

                    // Add your code here

                })
                .catch((err) => { alert(err); });
        });

        $("#replace-cards-button").on("click", function() {
            // Construct the cards to be replaced
            const cards = [];
            $("#player-hand .flipped").each(function(idx, el) {
                cards.push($(el).attr("data-card"));
            });
            const json = JSON.stringify({ cards });

            //
            // Replace the cards for the player by
            // sending a POST request to the server
            //
			fetch("/replacecards", {
				method:"POST",
				headers:{ "Content-Type":
						  "application/json"},
				body: json
			})
				.then((response) => response.json())
				.then((result) => {		
				
				// 1 如果 server 回 error，就提示並停下
				if (result.error) {
						alert(result.error);
						return;
					}				
				// 2 成功：更新玩家手牌並重畫
				player = result.hand;
				Hand.draw($("#player-hand"), player, true);                    
			})
			
			.catch((err) => { alert(err); });
            // Add your code here

        });

        $("#confirm-hand-button").on("click", function() {
            //
            // Confirm the hand for the player by sending
            // a GET request to the server
            //
			//fetch 不寫設定， 預設GET，下方為多餘
			//使用POST / PUT 送資料給 server 才需要寫{ method, headers, body }
			//fetch("/confirm", { method: "GET" })
			fetch("/confirm")
				.then((response) => response.json())//fetch 回來的是response物件，要轉成 JSON
				.then((result) => {
					if (result.error) {
							alert(result.error);
							return;
					}	
					// 1) Show both hands (face up)
					Hand.draw($("#player-hand"), result.player.hand, false);                    
					Hand.draw($("#computer-hand"), result.computer.hand, false);
					
					// 2) Show the result text
					if (result.winner === 1){
						$("#result").text("You win!!");
					}
					else if (result.winner === 2){
						$("#result").text("Computer win!!");
					}
					else{
						$("#result").text("It's a tie!!");
					}
					$("#result").show();
			})
            // Add your code here
			.catch((err) => { alert(err); });			
        });
    }

    return { init };
})();
