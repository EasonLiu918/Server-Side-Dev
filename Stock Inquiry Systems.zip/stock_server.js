const express = require("express");
const session = require("express-session");
const app = express();

const frontController = require("./controllers/front_controller");
const stockController = require("./controllers/stock_controller");

// Use the 'public' folder to serve static files
app.use(express.static("public"));

// Use the session middleware to maintain sessions
app.use(session({
    secret: "stock",
    resave: false,
    saveUninitialized: false,
    rolling: true,
    cookie: { maxAge: 300000 }
}));

// Use the urlencoded middleware
app.use(express.urlencoded({ extended: true }));

// Use the EJS template engine
app.set("view engine", "ejs")

// Use the front controller
app.get("/", frontController.welcome);

// Use the stock controller
app.post("/get", stockController.get);
app.get("/change", stockController.change);
app.get("/table", stockController.showTable);
app.get("/chart", stockController.showChart);

// Use a web server to listen at port 8000
app.listen(8000);
