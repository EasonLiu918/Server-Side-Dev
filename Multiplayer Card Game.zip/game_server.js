const express = require("express");

// Additional packages for handling authentication
const argon2 = require("argon2");
const fs = require("fs");
const session = require("express-session");

//stage 3.4 Additional packages for dealing with the cards
const deck = require("./deck");
const pokerHandUtils = require("poker-hand-utils");

// Create the Express app
const app = express();

//1.1 1.2
// Create the Socket.IO server
const { createServer } = require("http");
const { Server } = require("socket.io");
const httpServer = createServer(app);
const io = new Server(httpServer);

//1.3 
// Track signed-in players (max 4)
let onlineUsers = {};

// Use the 'public' folder to serve static files
app.use(express.static("public"));

// Use the json middleware to parse JSON data
app.use(express.json());

// Use the session middleware to maintain sessions
const gameSession = session({
    secret: "game",
    resave: false,
    saveUninitialized: false,
    rolling: true,
    cookie: { maxAge: 300000 }
});
app.use(gameSession);

// This helper function checks whether the text only contains word characters
function containWordCharsOnly(text) {
    return /^\w+$/.test(text);
}

// Handle the /register endpoint
app.post("/register", async (req, res) => {
    //
    // C. Reading the json input
    //

    // Get the JSON data from the body
    const { username, avatar, name, password } = req.body;

    //
    // D. Reading the users.json file
    //
    const users = JSON.parse(fs.readFileSync("data/users.json"));

    // Add your code here
    
    //
    // E. Checking for the user data correctness
    //
    if (username == "" || avatar == "" || name == "" || password == "") {
		res.json({ error: "Username/avatar/name/password cannot be empty." });
		return;
	}
	if (!containWordCharsOnly(username)) {
		res.json({ error: "Username can only contain underscores, letters or numbers." });
		return;
	}
	
    if (username in users) {
		res.json({ error: "Username has already been used." });
		return;
	}	
    // Add your code here

    //
    // G. Adding the new user account
    //

    // Hash the password
    const hash = await argon2.hash(password);

	users[username] = {
		"avatar" : avatar,
		"name" : name,
		"password" : hash
	};
    // Add your code here
	
    //
    // H. Saving the users.json file
    //
	fs.writeFileSync("data/users.json",
                     JSON.stringify(users, null, "  "));
    // Add your code here

    //
    // I. Sending a success response to the browser
    //
	res.json({ success: true });
});

// Handle the /signin endpoint
app.post("/signin", async (req, res) => {
    // Get the JSON data from the body
    const { username, password } = req.body;

    //
    // D. Reading the users.json file
    //
    const users = JSON.parse(fs.readFileSync("data/users.json"));

    // Add your code here

    //
    // E. Checking for username/password
    //
    if (!(username in users)) {
		res.json({ error: "Incorrect username/password." });
		return;
	}
	
    // Add your code here

    // REPLACE THIS CODE WITH YOUR CODE
	const user = users[username];
    //const user = { password: await argon2.hash("") };

    // If password is incorrect, return an error
    const verified = await argon2.verify(user.password, password);
    if (!verified) {
        res.json({ error: "Incorrect username/password." });
        return;
    }


	// 1.3
	// Max 4 signed-in users (count by username)
	
	const onlineCount = Object.keys(onlineUsers).length	
	
	// If this username is not already online, enforce the cap
	
	if (!(username in onlineUsers) && onlineCount >=4 ){
		res.json({ error: "The game is full already. Please try again later." });
		return;
	}


    //
    // G. Sending a success response with the user account
    //
	const sessionUser = {
		username : username,
		avatar : user.avatar,
		name : user.name
	};
	
	req.session.user = sessionUser;
	
	// Mark this user as online
	onlineUsers[username] = {
		username: username,
		avatar: user.avatar,
		name: user.name
	};
	
	
	res.json({ user: sessionUser });
	
    // Add your code here
 });

// Handle the /validate endpoint
app.get("/validate", (req, res) => {

    //
    // B. Getting req.session.user
    //
	if (!req.session.user){
        res.json({ error: "Not signed in." });
		return;
	}
    // Add your code here

    //
    // D. Sending a success response with the user account
    //
	res.json({ user: req.session.user });
});

// Handle the /signout endpoint
app.get("/signout", (req, res) => {

    //
    // Deleting req.session.user
    //

	//1.3
    // Delete the session information
    if (req.session.user) {
		const username = req.session.user.username;

		if (username && onlineUsers[username]) {
			delete onlineUsers[username];
		}

        delete req.session.user;
    }

    //
    // Sending a success response
    //
	
    res.json({ success: true });
});

//stage3.1
// Handle the web socket connection
//stage 3.3 socket identity
// A JavaScript object storing the players
let players = {}
// Indicate whether a game has started
let gameStarted = false;

io.on("connection", (socket) => {
    console.log("Player connected:", socket.id);

    // Wait for a player to join the game
    socket.on("join", (username) => {
        //
        // Handle the three error cases
        //
		
		// A game has already started
		if (gameStarted) {
			// Send an error message back to the browser
			socket.emit("join_error", "A Game Has Already Started.");
			return;
		}		
		
		// There are four players in the game
		if (Object.keys(players).length >= 4) {
			socket.emit("join_error", "The game is full already. Please try again later.");
			return;
		}		
		
		// Another player in the game has used the same name
		for (const id in players) {
			const player = players[id];

			// Check the name of the player
			if (player["username"] == username ){
				socket.emit("join_error", "The name already exists. Please choose another name.");
				return;
			}		
		}
		
        // Put the player into players by socket.id
        players[socket.id] = { username, ready: false , confirmed : false };
		
		socket.username = username;
        //
        // Send a success response to the browser
        //
        socket.emit("join_success");
		
        // For the main page: broadcast the players to the connected browsers
        //
		
		io.emit("update_players", players);
		console.log("players:", players);
    });
	
	socket.on("replacecards", (cards) => {
		
		const p = players[socket.id];
		
		// Check the hand sizes
		if (p.hand.length != 5) {
			// Send an error message back to the browser
			socket.emit("replace_error", "Hand not ready / game not started.");
			return
		}	
			
		// Check the remaining count
		if (p.remainingCount == 0) {
			socket.emit("replace_error", "You have no more replacement left!");
			return;
		}
		p.remainingCount--;
		
		//indexOf 教學例子
		//let player = ["4C","AD","3C","AH","KC"];
		//player.indexOf("AH"); // 回傳 3
		//player.indexOf("ZZ"); // 找不到回傳 -1
		//Replace the cards
		// Add your code here
		
		for (let i = 0; i < cards.length; i++) {
			const cardToReplace = cards[i]; 				// 要換的牌
			const idx = p.hand.indexOf(cardToReplace);		// 找它在 p.hand 的位置
			
			if (idx !== -1) {								// 找得到才換
				p.hand[idx] = deck.draw();					// 抽新牌替換
			}
		}	
		
        //
        // Send a success response to the browser
        //
        socket.emit("replace_success", { hand: p.hand, remainingCount: p.remainingCount});
		
		console.log("CP 3.3 -", JSON.stringify(cards));  // FOR MARKING - DON'T DELETE
		console.log("CP 3.4 -", JSON.stringify(p.hand)); // FOR MARKING - DON'T DELETE
	});	
	
	socket.on("confirm", () => {
		
		const p = players[socket.id];
		if (p.hand.length != 5) {
			// Send an error message back to the browser
			socket.emit("confirm_error", "Hand not ready / game not started.");
			return
		}
		
		p.confirmed = true;
		
		io.emit("update_players", players);
		
		const ids = Object.keys(players);
		if(ids.length < 2 ) return;
		
		const allConfirmed = ids.every(id => players[id].confirmed == true);
		if (!allConfirmed) return;
		
		// 4) 全部人都 confirmed -> 結算（多人版）
		//    用 createPokerHand() 做每個人的 hand 物件
		
	    const evaluated = ids.map(id => {
        const handStr = players[id].hand.join(" ");
        const handObj = pokerHandUtils.createPokerHand(handStr);
        return { id, username: players[id].username, hand: players[id].hand, handObj };
		});
		
		// ✅ 老師提示的方向：createPokerHand() 後自己比較
		// 但 poker-hand-utils 的「分數欄位名稱」你不一定知道
		// 所以我們用一個穩的方式：用 compareTo 兩兩比較找最大（仍然只比較兩個，但可以做多人 winner）
		// （老師說 compareTo 只能兩人 => 但我們不是拿它做「兩人遊戲」，而是拿它當 comparator，OK）
		
		let best = evaluated[0];
		let ties = [best];
		
		for (let i = 1; i < evaluated.length; i++) {
		
			const cur = evaluated[i];
			const c = pokerHandUtils.compareTo(best.handObj, cur.handObj);
			
			if (c == -1) {
				// cur 更大
				best = cur;
				ties = [cur];
			} 
			else if (c == 0) {
				
				// 平手
				ties.push(cur);
			}
		}
		
		io.emit("confirm_result", {
			winners: ties.map(x => ({ id: x.id, username: x.username })),
			
			players: evaluated.map(x => {
				const descObj = pokerHandUtils.getDescription(x.handObj);
				return {
				id: x.id,
				username: x.username,
				hand: x.hand,
				desc: descObj.rank
				};
			})
		});
	});
	socket.on("restart", () => {
		//至少兩個玩家才開局
		const ids = Object.keys(players);
		if(ids.length < 2 ) return;
		
		for(const id of ids){
			players[id].ready = false;
			players[id].confirmed = false;
		}
		
		gameStarted = false;
		startGame();
	});
	
	
	
    const startGame = function() {
		
		//stage 3.4
		deck.init();
		
		for (const id in players){
			const hand = [];
			
			for (let i = 0 ; i < 5; i++){
				hand.push(deck.draw());
			};
			
			// 存在 server 的 players 裡
			players[id].hand = hand;
			players[id].remainingCount = 2;
			
			//reset confirm
			players[id].confirmed = false;
			
			// 只發給該玩家自己
			io.to(id).emit("deal_hand", { hand, remainingCount: 2 });
		};
		
        // Tell the browsers to start the game
        //
		io.emit("game_start");
        // Add your code here

        gameStarted = true;
    };
	
    // Wait for a player to get ready in the game
    socket.on("ready", () => {
        // Mark the player as ready
        players[socket.id]["ready"] = true;

        //
        // Broadcast the players to the connected browsers
        //
		io.emit("update_players", players);
        // Add your code here

        //
        // Check if everybody is ready;
        // if so, start the game automatically
        //
		let allReady = true;
		const playerCount = Object.keys(players).length;
		if (playerCount < 2){
			return;
		}
		
		for (const id in players) {
			const player = players[id];
    
			// Check the status of each player
			if (player["ready"] == false) {
				allReady = false;
			}
		}
		
		if (allReady){
			startGame();
		}
        // Add your code here

        console.log("CP 3.6 -", players); // DON'T DELETE - FOR MARKING
    });
	
	
	
    // In case a player is disconnected from the game
    socket.on("disconnect", () => {
		console.log("[disconnect] socket.id =", socket.id);
		console.log("[disconnect] socket.username =", socket.username);
		
		// 看斷線前 players 有誰
		console.log("[disconnect] players BEFORE =", Object.keys(players));

        // Remove the player from the game
        if (players[socket.id]) 
		{
			console.log("[disconnect] removing player =", players[socket.id].username);
            delete players[socket.id];
		}
		if (socket.username && onlineUsers[socket.username])
		{
			console.log("[disconnect] removing onlineUser =", socket.username);
			delete onlineUsers[socket.username];
		}
		
		// 看斷線後 players/onlineUsers 狀態
		console.log("[disconnect] players AFTER =", Object.keys(players));
		console.log("[disconnect] onlineUsers =", Object.keys(onlineUsers));
		
		if (gameStarted)
		{
			gameStarted = false;
		
			for (const id in players)
			{
				players[id].ready = false;
				players[id].confirmed = false;
			}
			
			io.emit("game_aborted", { reason: "A player disconnected. Back to lobby." });
		}
		
        // Broadcast the players to the connected browsers
        io.emit("update_players", players);
    });
});
//1.1 1.2
// Use a web server to listen at port 8000
// Note that httpServer is used for a WebSocket server
httpServer.listen(8000, () => {
    console.log("The game server has started...");
});
