const express = require("express");

// Create the Express app
const app = express();

// Use the 'public' folder to serve static files
app.use(express.static("public"));

// Create the Socket.IO server
const { createServer } = require("http");
const { Server } = require("socket.io");
const httpServer = createServer(app);
const io = new Server(httpServer);

// A JavaScript object storing the players
let players = {}

// Indicate whether a game has started
let gameStarted = false;

// Handle the web socket connection
io.on("connection", (socket) => {
    console.log("Player connected:", socket.id);

    // Wait for a player to join the game
    socket.on("join", (name) => {
        //
        // Handle the three error cases
        //
		
		// A game has already started
		if (gameStarted) {
			// Send an error message back to the browser
			socket.emit("join_error", "A Game Has Already Started.");
			return;
		}		
		
		// There are four players in the game
		if (Object.keys(players).length == 4) {
			socket.emit("join_error", "The game is full already. Please try again later.");
			return;
		}		
		
		// Another player in the game has used the same name
		for (const id in players) {
			const player = players[id];

			// Check the name of the player
			if (player["name"] == name ){
				socket.emit("join_error", "The name already exists. Please choose another name.");
				return;
			}		
		}
        // Add your code here

        // Put the player in the players object
        players[socket.id] = { name, ready: false };

        //
        // Send a success response to the browser
        //
        socket.emit("join_success"); // REPLACE THIS WITH YOUR CODE
		
        //
        // For the main page: broadcast the players to the connected browsers
        //
		io.emit("update_players", players);
        // Add your code here

        console.log("CP 2.5 -", players); // DON'T DELETE - FOR MARKING
    });

    const startGame = function() {
        //
        // Tell the browsers to start the game
        //
		io.emit("game_start");
        // Add your code here

        gameStarted = true;
    };

    // Wait for a player to get ready in the game
    socket.on("ready", () => {
        // Mark the player as ready
        players[socket.id]["ready"] = true;

        //
        // Broadcast the players to the connected browsers
        //
		io.emit("update_players", players);
        // Add your code here

        //
        // Check if everybody is ready;
        // if so, start the game automatically
        //
		let allReady = true;
		const playerCount = Object.keys(players).length;
		if (playerCount < 2){
			return;
		}
		
		for (const id in players) {
			const player = players[id];
    
			// Check the status of each player
			if (player["ready"] == false) {
				allReady = false;
			}
		}
		
		if (allReady){
			startGame();
		}
        // Add your code here

        console.log("CP 3.6 -", players); // DON'T DELETE - FOR MARKING
    });

    const finishGame = function() {
        //
        // Tell the browsers the game has finished
        //
		io.emit("game_end", players);
		
        // Add your code here

        // Reset the game
        players = {};
        gameStarted = false;
    };

    // Set up the choose event
    socket.on("choose", (sign) => {
        // Assign the sign to the player
        players[socket.id]["sign"] = sign;

        //
        // Check if everybody has selected a hand sign;
        // if so, the game will finish
        //
		let allChosen = true;
		
		
		for (const id in players) {
			const player = players[id];
    
			if (!player["sign"]){
				allChosen = false;
			}		
		}		
		
		if (allChosen){
			finishGame();
		}
        // Add your code here

        console.log("CP 4.3 -", players); // DON'T DELETE - FOR MARKING
    });

    // In case a player is disconnected from the game
    socket.on("disconnect", () => {
        // Remove the player from the game
        if (players[socket.id]) {
            delete players[socket.id];

            // Broadcast the players to the connected browsers
            io.emit("update_players", players);
        }
    });
});

// Use a web server to listen at port 8000
// Note that httpServer is used for a WebSocket server
httpServer.listen(8000, () => {
    console.log("The game server has started...");
});
