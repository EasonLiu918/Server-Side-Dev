const express = require("express");

// Additional packages for handling authentication
const argon2 = require("argon2");
const fs = require("fs");
const session = require("express-session");

// Create the Express app
const app = express();

// Use the 'public' folder to serve static files
app.use(express.static("public"));

// Use the json middleware to parse JSON data
app.use(express.json());

// Use the session middleware to maintain sessions
const gameSession = session({
    secret: "game",
    resave: false,
    saveUninitialized: false,
    rolling: true,
    cookie: { maxAge: 300000 }
});
app.use(gameSession);

// This helper function checks whether the text only contains word characters
function containWordCharsOnly(text) {
    return /^\w+$/.test(text);
}

// Handle the /register endpoint
app.post("/register", async (req, res) => {
    //
    // C. Reading the json input
    //

    // Get the JSON data from the body
    const { username, avatar, name, password } = req.body;

    //
    // D. Reading the users.json file
    //
    const users = JSON.parse(fs.readFileSync("data/users.json"));

    // Add your code here
    
    //
    // E. Checking for the user data correctness
    //
    if (username == "" || avatar == "" || name == "" || password == "") {
		res.json({ error: "Username/avatar/name/password cannot be empty." });
		return;
	}
	if (!containWordCharsOnly(username)) {
		res.json({ error: "Username can only contain underscores, letters or numbers." });
		return;
	}
	
    if (username in users) {
		res.json({ error: "Username has already been used." });
		return;
	}	
    // Add your code here

    //
    // G. Adding the new user account
    //

    // Hash the password
    const hash = await argon2.hash(password);

	users[username] = {
		"avatar" : avatar,
		"name" : name,
		"password" : hash
	};
    // Add your code here
	
    //
    // H. Saving the users.json file
    //
	fs.writeFileSync("data/users.json",
                     JSON.stringify(users, null, "  "));
    // Add your code here

    //
    // I. Sending a success response to the browser
    //
	res.json({ success: true });
	// res.json({ error: "Not implemented!" });
});

// Handle the /signin endpoint
app.post("/signin", async (req, res) => {
    // Get the JSON data from the body
    const { username, password } = req.body;

    //
    // D. Reading the users.json file
    //
    const users = JSON.parse(fs.readFileSync("data/users.json"));

    // Add your code here

    //
    // E. Checking for username/password
    //
    if (!(username in users)) {
		res.json({ error: "Incorrect username/password." });
		return;
	}
	
    // Add your code here

    // REPLACE THIS CODE WITH YOUR CODE
	const user = users[username];
    //const user = { password: await argon2.hash("") };

    // If password is incorrect, return an error
    const verified = await argon2.verify(user.password, password);
    if (!verified) {
        res.json({ error: "Incorrect username/password." });
        return;
    }

    //
    // G. Sending a success response with the user account
    //
	const sessionUser = {
		username : username,
		avatar : user.avatar,
		name : user.name
	};
	
	req.session.user = sessionUser;
	
	res.json({ user: sessionUser });
	
    // Add your code here
 
    //res.json({ error: "Not implemented!" });
});

// Handle the /validate endpoint
app.get("/validate", (req, res) => {

    //
    // B. Getting req.session.user
    //
	if (!req.session.user){
        res.json({ error: "Not signed in." });
		return;
	}
    // Add your code here

    //
    // D. Sending a success response with the user account
    //
	res.json({ user: req.session.user });
    //res.json({ error: "Not implemented!" });
});

// Handle the /signout endpoint
app.get("/signout", (req, res) => {

    //
    // Deleting req.session.user
    //

    // Delete the session information
    if (req.session.user) {
        delete req.session.user;
    }

    //
    // Sending a success response
    //

    res.json({ success: true });
});

// Use a web server to listen at port 8000
app.listen(8000, () => {
    console.log("The game server has started...");
});
